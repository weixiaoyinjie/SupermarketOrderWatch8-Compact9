package com.supermarket.orderreminder;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.android.gms.wearable.PutDataMapRequest;
import com.google.android.gms.wearable.PutDataRequest;
import com.google.android.gms.wearable.Wearable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Full phone app is authoritative; each calendar day is a durable Wear Data Layer item. */
public final class SyncPublisher {
    private static final String TAG = "OrderSync";
    public static final String DAY_PATH = "/orders/day/";
    public static final String PATH_REQUEST = "/orders/request";
    public static final String PATH_SET_DONE = "/orders/set_done";
    public static final String PATH_ACK = "/orders/ack";
    private static final ExecutorService WORK = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean RUNNING = new AtomicBoolean();
    private static final AtomicBoolean DIRTY = new AtomicBoolean();

    private SyncPublisher() { }

    public static void schedule(Context context) {
        Context app = context.getApplicationContext();
        DIRTY.set(true);
        if (!RUNNING.compareAndSet(false, true)) return;
        WORK.execute(() -> {
            try {
                do {
                    DIRTY.set(false);
                    try (Db db = new Db(app)) {
                        LocalDate today = LocalDate.now();
                        for (int i = -1; i <= 7; i++) publish(app, db, today.plusDays(i), false);
                    } catch (Exception e) { Log.e(TAG, "发布任务失败", e); }
                } while (DIRTY.get());
            } finally {
                RUNNING.set(false);
                if (DIRTY.get()) schedule(app);
            }
        });
    }

    public static void publishOne(Context context, LocalDate date, boolean force) {
        Context app = context.getApplicationContext();
        WORK.execute(() -> {
            try (Db db = new Db(app)) { publish(app, db, date, force); }
            catch (Exception e) { Log.e(TAG, "发布所选日期失败", e); }
        });
    }

    private static void publish(Context app, Db db, LocalDate date, boolean force) throws Exception {
        JSONObject payload = new JSONObject();
        payload.put("schema", 1);
        payload.put("date", date.toString());
        JSONArray orders = new JSONArray();
        for (Entry e : db.forDate(date)) {
            if (e.kind != 0 || e.repeatType == 3) continue;
            orders.put(item(e, date.toString(), db.isDone(e.id, date.toString())));
        }
        JSONArray tasks = new JSONArray();
        for (Db.TaskOccurrence item : db.tasksForDate(date)) {
            tasks.put(item(item.entry, item.dueDate.toString(), item.completed));
        }
        payload.put("orders", orders);
        payload.put("tasks", tasks);
        byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
        if (bytes.length > 90000) {
            Log.e(TAG, "单日任务超过安全上限，无法同步: " + date);
            return;
        }
        String digest = Integer.toHexString(java.util.Arrays.hashCode(bytes)) + ":" + bytes.length;
        SharedPreferences prefs = app.getSharedPreferences("watch_sync_cache", Context.MODE_PRIVATE);
        String cacheKey = "sha_" + date;
        if (!force && digest.equals(prefs.getString(cacheKey, ""))) return;
        PutDataMapRequest data = PutDataMapRequest.create(DAY_PATH + date);
        data.getDataMap().putString("json", payload.toString());
        data.getDataMap().putLong("sent_at", System.currentTimeMillis());
        PutDataRequest request = data.asPutDataRequest();
        request.setUrgent();
        Wearable.getDataClient(app).putDataItem(request)
                .addOnSuccessListener(item -> prefs.edit().putString(cacheKey, digest).apply())
                .addOnFailureListener(e -> Log.e(TAG, "Data Layer 发布失败: " + date, e));
    }

    private static JSONObject item(Entry e, String occurrenceDate, boolean done) throws Exception {
        JSONObject o = new JSONObject();
        o.put("id", e.id);
        o.put("title", e.title);
        o.put("due", occurrenceDate);
        o.put("done", done);
        o.put("kind", e.kind);
        if (e.kind == 1) o.put("overdue", occurrenceDate.compareTo(LocalDate.now().toString()) < 0);
        return o;
    }
}
