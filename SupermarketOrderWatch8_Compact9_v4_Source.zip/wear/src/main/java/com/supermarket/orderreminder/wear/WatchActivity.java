package com.supermarket.orderreminder.wear;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.wearable.DataItem;
import com.google.android.gms.wearable.Wearable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

/**
 * Watch-only checklist. The initial viewport contains the date and up to nine
 * compact, one-line tasks. Additional tasks scroll below; controls are below
 * the entire task list. Creation and editing remain on the phone unchanged.
 */
public final class WatchActivity extends Activity {
    private static final int BG = Color.BLACK;
    private static final int CARD = Color.rgb(24, 31, 35);
    private static final int WHITE = Color.rgb(244, 247, 248);
    private static final int MUTED = Color.rgb(165, 175, 179);
    private static final int GREEN = Color.rgb(100, 226, 179);
    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("M月d日 EEE", Locale.CHINA);

    private LocalDate day = LocalDate.now();
    private ScrollView scroll;
    private LinearLayout content;
    private TextView status;
    private int viewportHeight;
    private int viewportWidth;
    private boolean listening = false;
    private String banner = "";
    private final ArrayList<TextView> taskViews = new ArrayList<>();

    private final BroadcastReceiver updates = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent intent) {
            if (WatchStore.BROADCAST_UPDATED.equals(intent.getAction())) {
                banner = "";
                render();
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter filter = new IntentFilter(WatchStore.BROADCAST_UPDATED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updates, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(updates, filter);
        }
        listening = true;
        render();
        reloadDataItems();
        WatchLink.flush(this);
        sync(false);
    }

    @Override protected void onStop() {
        if (listening) { unregisterReceiver(updates); listening = false; }
        super.onStop();
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + .5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String label, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(label);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setIncludeFontPadding(false);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private LinearLayout column() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        return v;
    }

    private LinearLayout.LayoutParams layout(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(top), 0, dp(bottom));
        return p;
    }

    private void build() {
        scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        content = column();
        content.setPadding(0, 0, 0, dp(20));
        scroll.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        scroll.setOnScrollChangeListener((v, sx, sy, oldX, oldY) -> updateRoundInsets());
        scroll.addOnLayoutChangeListener((v, l, t, r, b, oldL, oldT, oldR, oldB) -> {
            int height = b - t;
            int width = r - l;
            if (height > 0 && width > 0 &&
                    (height != viewportHeight || width != viewportWidth)) {
                viewportHeight = height;
                viewportWidth = width;
                scroll.post(() -> {
                    if (!isFinishing() && !isDestroyed()) render();
                });
            }
        });
        render();
    }

    private int screenHeight() {
        return viewportHeight > 0 ? viewportHeight : getResources().getDisplayMetrics().heightPixels;
    }

    private void render() {
        if (content == null) return;
        // Keep the scroll position when a task is completed or new sync data arrives.
        int oldScrollY = scroll.getScrollY();
        content.removeAllViews();
        taskViews.clear();

        int heightPx = screenHeight();
        float heightDp = heightPx / getResources().getDisplayMetrics().density;
        int topDp = Math.max(14, Math.min(20, Math.round(heightDp * .075f)));
        int dateHeightDp = Math.max(19, Math.min(23, Math.round(heightDp * .09f)));
        int bottomDp = Math.max(5, Math.min(10, Math.round(heightDp * .03f)));
        // Nine text rows occupy the available vertical space, with no large cards.
        int rowHeightDp = Math.max(18, Math.min(24,
                (int) ((heightDp - topDp - dateHeightDp - bottomDp - 3f) / 9f)));
        int fontSp = rowHeightDp < 20 ? 11 : 12;

        LinearLayout firstPage = column();
        firstPage.setMinimumHeight(heightPx);
        firstPage.setPadding(0, dp(topDp), 0, dp(bottomDp));
        content.addView(firstPage, new LinearLayout.LayoutParams(-1, -2));

        // No large title, date navigation, sync button or status panel above tasks.
        TextView heading = text(day.format(DATE_FMT), 12, WHITE, true);
        heading.setGravity(Gravity.CENTER);
        heading.setSingleLine(true);
        firstPage.addView(heading, new LinearLayout.LayoutParams(-1, dp(dateHeightDp)));

        JSONObject snap = WatchStore.getSnapshot(this, day.toString());
        JSONArray orders = snap == null ? null : snap.optJSONArray("orders");
        JSONArray tasks = snap == null ? null : snap.optJSONArray("tasks");
        int all = (orders == null ? 0 : orders.length()) +
                  (tasks == null ? 0 : tasks.length());
        int finished = completed(orders) + completed(tasks);

        if (snap == null) {
            TextView empty = text("尚未同步当天任务\n请向下滑动，点击同步", 12, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(30), dp(10), dp(30), dp(10));
            firstPage.addView(empty, layout(-1, dp(75), 10, 0));
        } else if (all == 0) {
            TextView empty = text("当天没有任务", 12, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            firstPage.addView(empty, layout(-1, dp(48), 10, 0));
        } else {
            addRows(firstPage, orders, true, rowHeightDp, fontSp);
            addRows(firstPage, tasks, false, rowHeightDp, fontSp);
        }

        // This is after one complete viewport (or below overflow tasks).
        // It can be reached by scrolling down, without covering the task page.
        LinearLayout lowerPage = column();
        lowerPage.setPadding(dp(27), dp(22), dp(27), dp(24));
        content.addView(lowerPage, new LinearLayout.LayoutParams(-1, -2));

        TextView manageTitle = text("日期与同步", 16, WHITE, true);
        manageTitle.setGravity(Gravity.CENTER);
        lowerPage.addView(manageTitle, layout(-1, dp(32), 0, 10));
        addDatePicker(lowerPage);

        Button syncButton = new Button(this);
        syncButton.setText("⟳ 同步手机任务");
        syncButton.setTextColor(Color.BLACK);
        syncButton.setTextSize(14);
        syncButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        syncButton.setAllCaps(false);
        syncButton.setPadding(dp(8), 0, dp(8), 0);
        syncButton.setBackground(rounded(GREEN, 24));
        syncButton.setOnClickListener(v -> sync(true));
        lowerPage.addView(syncButton, layout(-1, dp(43), 8, 7));

        TextView counts = text("共 " + all + " 项   已完成 " + finished + " 项", 12, GREEN, true);
        counts.setGravity(Gravity.CENTER);
        lowerPage.addView(counts, layout(-1, dp(25), 2, 1));

        status = text("", 11, MUTED, false);
        status.setGravity(Gravity.CENTER);
        status.setMaxLines(2);
        status.setEllipsize(TextUtils.TruncateAt.END);
        lowerPage.addView(status, layout(-1, dp(36), 1, 8));
        renderStatus();

        TextView help = text("轻点未完成任务即可标记完成\n添加、修改、撤销请在手机操作", 11, MUTED, false);
        help.setGravity(Gravity.CENTER);
        lowerPage.addView(help, layout(-1, dp(48), 0, 0));

        scroll.post(() -> {
            if (isFinishing() || isDestroyed()) return;
            scroll.scrollTo(0, oldScrollY);
            updateRoundInsets();
        });
    }

    private void addRows(LinearLayout list, JSONArray rows, boolean isOrder,
                         int rowHeightDp, int fontSp) {
        if (rows == null) return;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            final long id = row.optLong("id", -1);
            final String due = row.optString("due", day.toString());
            final String name = row.optString("title", "未命名");
            final boolean done = WatchStore.done(this, row);
            final boolean queued = WatchStore.hasPending(this, id, due);
            String dateSuffix = !due.equals(day.toString())
                    ? " · " + (due.length() > 5 ? due.substring(5) : due) : "";
            String label = (done ? "✓" : "○") + " " + (isOrder ? "订" : "事") + " " +
                    name + (queued ? " ·待同步" : "") + dateSuffix;

            TextView item = text(label, fontSp, done ? GREEN : WHITE, !done);
            item.setSingleLine(true);
            item.setEllipsize(TextUtils.TruncateAt.END);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(dp(12), 0, dp(12), 0);
            item.setBackground(new RippleDrawable(
                    ColorStateList.valueOf(CARD), null, null));
            item.setContentDescription((isOrder ? "订货，" : "事务，") + name +
                    (done ? "，已完成" : "，点击完成") + (queued ? "，待同步" : ""));
            if (!done && !queued && id > 0) {
                item.setClickable(true);
                item.setOnClickListener(v -> {
                    WatchStore.queue(this, id, due, true);
                    banner = "已在手表完成 · 正在回传手机";
                    render();
                    WatchLink.flush(this);
                });
            }
            list.addView(item, new LinearLayout.LayoutParams(-1, dp(rowHeightDp)));
            taskViews.add(item);
        }
    }

    /** Recompute left/right text insets as rows scroll across the round screen. */
    private void updateRoundInsets() {
        if (scroll == null || taskViews.isEmpty()) return;
        int width = scroll.getWidth();
        int height = scroll.getHeight();
        if (width <= 0 || height <= 0) return;
        int[] scrollLocation = new int[2];
        int[] rowLocation = new int[2];
        scroll.getLocationOnScreen(scrollLocation);
        float radius = Math.min(width, height) / 2f;
        float centerY = height / 2f;
        for (TextView row : taskViews) {
            row.getLocationOnScreen(rowLocation);
            float top = rowLocation[1] - scrollLocation[1];
            float bottom = top + row.getHeight();
            if (bottom < 0 || top > height || row.getHeight() == 0) continue;
            float a = Math.max(0f, top + dp(1));
            float b = Math.min(height, bottom - dp(1));
            float distance = Math.max(Math.abs(a - centerY), Math.abs(b - centerY));
            distance = Math.min(radius - dp(2), distance);
            // Distance from the circular edge at the most constrained row endpoint.
            float halfChord = (float) Math.sqrt(Math.max(0,
                    radius * radius - distance * distance));
            int inset = Math.max(dp(9), (int) Math.ceil(width / 2f - halfChord) + dp(3));
            // Keep at least some text visible if the row crosses the very edge.
            inset = Math.min(inset, width / 2 - dp(18));
            if (Math.abs(row.getPaddingLeft() - inset) > 1) {
                row.setPadding(inset, 0, inset, 0);
            }
        }
    }

    private void addDatePicker(LinearLayout destination) {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        Button prev = smallButton("‹");
        prev.setContentDescription("上一天");
        prev.setEnabled(day.isAfter(LocalDate.now().minusDays(1)));
        prev.setOnClickListener(v -> changeDay(day.minusDays(1)));
        nav.addView(prev, new LinearLayout.LayoutParams(dp(42), dp(40)));

        TextView date = text(labelDay(), 12, WHITE, true);
        date.setSingleLine(true);
        date.setGravity(Gravity.CENTER);
        date.setEllipsize(TextUtils.TruncateAt.END);
        nav.addView(date, new LinearLayout.LayoutParams(0, dp(40), 1));

        Button next = smallButton("›");
        next.setContentDescription("下一天");
        next.setEnabled(day.isBefore(LocalDate.now().plusDays(7)));
        next.setOnClickListener(v -> changeDay(day.plusDays(1)));
        nav.addView(next, new LinearLayout.LayoutParams(dp(42), dp(40)));
        destination.addView(nav, layout(-1, dp(43), 0, 0));
    }

    private void changeDay(LocalDate newDay) {
        day = newDay;
        scroll.scrollTo(0, 0);
        render();
        sync(false);
    }

    private String labelDay() {
        LocalDate now = LocalDate.now();
        String which = day.equals(now) ? "今天 " : day.equals(now.plusDays(1)) ? "明天 " : "";
        return which + day.format(DATE_FMT);
    }

    private Button smallButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(22);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(rounded(CARD, 20));
        return b;
    }

    private void sync(boolean manual) {
        if (manual) banner = "请求同步中…";
        renderStatus();
        WatchLink.flush(this);
        WatchLink.request(this, day, message -> runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            banner = message;
            renderStatus();
        }));
        reloadDataItems();
    }

    private void reloadDataItems() {
        Wearable.getDataClient(this).getDataItems()
                .addOnSuccessListener(items -> {
                    try {
                        for (DataItem item : items) WatchSyncService.accept(this, item);
                    } finally { items.release(); }
                    if (!isFinishing() && !isDestroyed()) render();
                })
                .addOnFailureListener(error -> {
                    banner = "无法读取同步数据 · 可查看离线清单";
                    renderStatus();
                });
    }

    private int completed(JSONArray rows) {
        if (rows == null) return 0;
        int n = 0;
        for (int i = 0; i < rows.length(); ++i) {
            JSONObject r = rows.optJSONObject(i);
            if (r != null && WatchStore.done(this, r)) ++n;
        }
        return n;
    }

    private void renderStatus() {
        if (status == null) return;
        int pending = WatchStore.pendingCount(this);
        String line;
        if (pending > 0) line = "待回传 " + pending + " 项 · 手机连接后自动重试";
        else if (!banner.isEmpty()) line = banner;
        else {
            long updated = WatchStore.receivedAt(this, day.toString());
            line = updated > 0
                    ? "已收到手机数据 · " + new java.text.SimpleDateFormat("HH:mm",
                        Locale.getDefault()).format(new java.util.Date(updated))
                    : "等待手机同步 · 支持离线查看";
        }
        status.setText(line);
    }
}
